package SortedList;


/**
 * Implementation of a SortedList using a SinglyLinkedList
 * @author Fernando J. Bermudez & Juan O. Lopez
 * @author Alejandro M. Cruzado Ruiz
 * @version 2.0
 * @since 10/16/2021
 */
public class SortedLinkedList<E extends Comparable<? super E>> extends AbstractSortedList<E> {

	@SuppressWarnings("unused")
	private static class Node<E> {

		private E value;
		private Node<E> next;
		/**
		 * Two parameter constructor to initialize Nodes
		 * @param value data that will be stored at this node
		 * @param next reference to the next node
		 */
		public Node(E value, Node<E> next) {
			this.value = value;
			this.next = next;
		}

		public Node(E value) {
			this(value, null); // Delegate to other constructor
		}

		public Node() {
			this(null, null); // Delegate to other constructor
		}

		public E getValue() {
			return value;
		}

		public void setValue(E value) {
			this.value = value;
		}

		public Node<E> getNext() {
			return next;
		}

		public void setNext(Node<E> next) {
			this.next = next;
		}

		public void clear() {
			value = null;
			next = null;
		}				
	} // End of Node class
 	
	private Node<E> head; // First DATA node (This is NOT a dummy header node)
	/**
	 * Default SortedLinkedList sontructor. Initializes with size 0 and does NOT use a dummy header.
	 */
	public SortedLinkedList() {
		head = null;
		currentSize = 0;
	}

	@Override
	public void add(E e) {
		Node<E> newNode = new Node<E>(e);
		//list was empty so now we only have one node
		if (this.head == null){
			this.head = newNode;
			currentSize++;
			return;
		}
		Node<E> curNode = head;
		Node<E> lastNode = null;
		while (curNode != null){
			if (curNode.getValue().compareTo(e) > 0){ //position found
				if (lastNode == null){ //start of list
					newNode.next = this.head;
					this.head = newNode;
				} else { //somewhere in the list
					lastNode.next = newNode;
					newNode.next = curNode;
				}
				this.currentSize++;
				return; //element added, exit out
			}
			lastNode = curNode; //iterate through list
			curNode = curNode.next;
		}
		// We reached the end of the list, add the element at the end
		lastNode.next = newNode;
		this.currentSize++;
	}
	@Override
	public boolean remove(E e) {
		Node<E> lastNode, curNode; //pointers to track position
		curNode = this.head;
		lastNode = null;
		while (curNode != null){
			if (curNode.getValue().compareTo(e) == 0){ // element found
				if (lastNode != null){ //element somewhere in middle of list
					lastNode.next = curNode.next;
				} else{ // element at the start of the list
					this.head = this.head.next;
				}
				curNode.clear(); //clear removed node
				currentSize--;
				return true;
			}
			lastNode = curNode; //iterate
			curNode = curNode.next;
		}
		return false; //element not found
	}

	@Override
	public E removeIndex(int index) {
		if (index < 0 || index >= currentSize){ //exit early if invalid input
			throw new IndexOutOfBoundsException();
		}
		E value = null;
		Node<E> lastNode = null;
		Node <E> curNode = head;
		for (int i = 0; i < index; i++){ //iterate to correct position
			lastNode = curNode;
			curNode = curNode.next;
		}
		if (lastNode == null){ //element to remove is at the beginning
			this.head = this.head.next;
		} else{
			lastNode.next = curNode.next;
		}
		value = curNode.value;
		curNode.clear(); //clear removed node
		currentSize--;
		return value;
	}

	@Override
	public int firstIndex(E e) {
		Node<E> curNode;
		curNode = this.head;
		int i = 0;
		while (curNode != null){ //loop until entire list is traversed
			if (curNode.getValue().compareTo(e) == 0){ //element found
				return i;
			}
			curNode = curNode.next;
			i++; //iterate
		}
		return -1; //element not found
	}

	@Override
	public E get(int index) {
		if (index < 0 || index >= currentSize){ //exit early if invalid input
			throw new IndexOutOfBoundsException();
		}
		Node <E> curNode = head;
		int currIdx = 0;
		while (curNode != null){
			if (currIdx >= index){ //correct position found
				return curNode.value;
			}
			currIdx++; //continue iterating
			curNode = curNode.next;
		}
		return null; //element not found at inputted position 
	}

	

	@SuppressWarnings("unchecked")
	@Override
	public E[] toArray() {
		int index = 0;
		E[] theArray = (E[]) new Comparable[size()]; // Cannot use Object here
		for(Node<E> curNode = this.head; index < size() && curNode  != null; curNode = curNode.getNext(), index++) {
			theArray[index] = curNode.getValue();
		}
		return theArray;
	}

}
